import React from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import LoginForm from "./LoginForm";

export default function CustomModal(props) {
  return (
    <div className="ModalDialog">
      <Dialog
        open={props.show}
        onClose={props.close}
        aria-labelledby="form-dialog-title"
      >
        <DialogContent>
          <LoginForm />
        </DialogContent>
      </Dialog>
    </div>
  );
}
