import React, {useState} from 'react';
import { Carousel } from 'react-bootstrap';

function CustomCarousel () {
    const [index, setIndex] = useState(0);

    const handleSelect = (selectedIndex, e) => {
        setIndex(selectedIndex);
    };
    return (
        <div className='carousel-container my-3'>
        <Carousel activeIndex={index} onSelect={handleSelect}>
            {/* <Carousel.Item>
                <img
                className="d-block w-100"
                src="Login_img_1.jpg"
                alt="First slide"
                />
                <Carousel.Caption>
                <h5 className="text-left mb-0">Welcome to</h5>
                <h2 className="text-left">eEOMB PORTAL</h2>
                </Carousel.Caption>
            </Carousel.Item> */}
            <Carousel.Item>
                <img
                className="d-block w-100"
                src="hero1.jpg"
                alt="Second slide"
                />
                <Carousel.Caption>
                <h1 className="text-dark display-3">News Flash</h1>
                <h3 className="text-dark">lorem ipsum dolor</h3>
                </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
            <img
            className="d-block w-100"
            src="hero2.jpg"
            alt="Third slide"
            />
            <Carousel.Caption>
            <h1 className="text-dark display-3">News flash</h1>
            <h3 className="text-dark">lorem ipsum dolor sit amet</h3>
            </Carousel.Caption>
        </Carousel.Item>
        </Carousel>
        </div>
    );
}
export default CustomCarousel;