/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Checkbox from '@material-ui/core/Checkbox';

export default function EnhancedTableHead(props) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
    showHeaderCheckBox
  } = props;
  const createSortHandler = property => event => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {!props.isSearch && props.isSearch !== undefined ? (
          <TableCell padding="checkbox" style={{ width: '60px' }}>
            {showHeaderCheckBox ? <Checkbox
              indeterminate={numSelected > 0 && numSelected < rowCount}
              checked={numSelected === rowCount && numSelected !== 0}
              onChange={onSelectAllClick}
              color="primary"
              inputProps={{ 'aria-label': 'select all desserts' }}
            /> : null}{' '}
            <a aria-hidden="true" hidden="true">
              {' '}
              check box{' '}
            </a>
          </TableCell>
        ) : null}
        {props.headCells.map(headCell => (
          <TableCell
            key={headCell.id}
            // align={headCell.numeric || headCell.isBalance? 'right' : 'left'}
            // align={headCell.numeric ? 'right' : 'left'}
            align={'left'}
            padding="default"
            sortDirection={orderBy === headCell.id ? order : false}
            style={{ width: headCell.width, fontSize: headCell.fontSize }}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={order}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <span>{order === 'desc' ? '' : ''}</span>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(['asc', 'desc']).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired
};
