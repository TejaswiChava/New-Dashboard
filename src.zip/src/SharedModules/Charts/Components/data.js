export const areas = [{
    country: 'Russia',
    area: 12
  }, {
    country: 'Canada',
    area: 7
  }, {
    country: 'USA',
    area: 7
  }, {
    country: 'China',
    area: 7
  }, {
    country: 'Brazil',
    area: 6
  }, {
    country: 'Australia',
    area: 5
  }, {
    country: 'India',
    area: 2
  }, {
    country: 'Others',
    area: 55
  }];

  
  export const internetLanguages = [{
    language: 'English',
    percent: 55.5
  }, {
    language: 'Chinese',
    percent: 4.0
  }, {
    language: 'Spanish',
    percent: 4.3
  }, {
    language: 'Japanese',
    percent: 4.9
  }, {
    language: 'Portuguese',
    percent: 2.3
  }, {
    language: 'German',
    percent: 5.6
  }, {
    language: 'French',
    percent: 3.8
  }, {
    language: 'Russian',
    percent: 6.3
  }, {
    language: 'Italian',
    percent: 1.6
  }, {
    language: 'Polish',
    percent: 1.8
  }];

  export const maleAgeData = [{
    state: 'Germany',
    young: 6.7,
    middle: 28.6,
    older: 5.1
  }, {
    state: 'Japan',
    young: 9.6,
    middle: 43.4,
    older: 9
  }, {
    state: 'Russia',
    young: 13.5,
    middle: 49,
    older: 5.8
  }, {
    state: 'USA',
    young: 30,
    middle: 90.3,
    older: 14.5
  }];
  
  