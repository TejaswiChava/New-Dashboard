import React from 'react';

import { Chart, Series, CommonSeriesSettings, Legend, ValueAxis, Title, Export, Tooltip } from 'devextreme-react/chart';

import { maleAgeData } from './data.js';

export default function CustomStackedBarGraph(props) {
  const customizeTooltip = (arg) => {
    return {
      text: `${arg.seriesName } years: ${ arg.valueText}`
    };
  }

  return (
    <Chart
        id="chart"
        title="Age Structure"
        dataSource={maleAgeData}
      >
        <CommonSeriesSettings argumentField="state" type="stackedBar" />
        <Series
          valueField="young"
          name="0-14"
        />
        <Series
          valueField="middle"
          name="15-64"
        />
        <Series
          valueField="older"
          name="65 and older"
        />
        <ValueAxis position="right">
          <Title text="millions" />
        </ValueAxis>
        <Legend
          verticalAlignment="bottom"
          horizontalAlignment="center"
          itemTextPosition="top"
        />
        <Export enabled={true} />
        <Tooltip
          enabled={true}
          location="edge"
          customizeTooltip={customizeTooltip}
        />
      </Chart>
  );
}
