/* eslint-disable no-unused-vars */
import React from "react";
import { Route, Switch } from "react-router-dom";
import Dashboard from './Modules/Dashboard/Components/Dashboard';
import Home from './Modules/Home/Components/Home';
import DashboardLayout from './SharedModules/Layout/Components/DashboardLayout';
import EmployeeForm from './Modules/Resource/Components/employeeDetails/EmployeeForm';
import Resource from './Modules/Resource/Components/LandingPage/Resource'

export default function RoutesApp(props) {
  return (
    <React.Fragment>
      <Switch>
      <Route exact path="/" component={Home} />
      <Route exact path="/dashboard" component={Dashboard} />
      <Route exact path="/dashboardLayout" component={DashboardLayout} />
      <Route exact path = "/employee" component = {EmployeeForm} />
      <Route exact path = "/resource" component = {Resource} />
      </Switch>
    </React.Fragment>
  );
}
