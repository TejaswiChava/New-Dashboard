import React from "react";
import Table from "../../../../SharedModules/Table/Components/Table";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

const headCells = [
  { id: "SNo", numeric: false, disablePadding: true, label: "S No" },
  { id: "SkillSet", numeric: true, disablePadding: false, label: "Skill Set" },
  {
    id: "Action",
    numeric: true,
    disablePadding: false,
    label: "Action",
    isAction: true,
  },
];
function createData(SNo, SkillSet) {
  return { SNo, SkillSet };
}

const rows = [
  createData("1", "Java", "790231", "Active", 4.0),
  createData("2", ".Net", 9.0, 37, 4.3),
  createData("3", "React Js", 16.0, 24, 6.0),
  createData("4", "Angular Js", 3.7, 67, 4.3),
  createData("5", "Javascript", 16.0, 49, 3.9),
];

function SkillSetDetails() {
  return (
    <div>
      <div className="form-wrapper">
        <div className="mui-custom-form">
          <TextField
            id="Skill"
            fullWidth
            label="Skill"
            type="string"
            inputProps={{ maxLength: 15 }}
            value=""
            // onChange={}
            InputLabelProps={{
              shrink: true,
            }}
          ></TextField>
          <Button
            variant="contained"
            color="primary"
          >
            Add
          </Button>
        </div>
      </div>
      <div>
        <Table tableData={rows} headCells={headCells} />
      </div>
    </div>
  );
}
export default SkillSetDetails;
