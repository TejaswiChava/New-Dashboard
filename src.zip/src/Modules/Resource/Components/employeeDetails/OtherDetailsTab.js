import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";

function OtherDetails() {
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="work-location"
              fullWidth
              label="Work location"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select One"
                value="Please Select One"
              >
                Please Select One
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="building"
              fullWidth
              label="Building"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="floor"
              fullWidth
              label="Floor"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select One"
                value="Please Select One"
              >
                Please Select One
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="seat-type"
              fullWidth
              label="Seat Type"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select One"
                value="Please Select One"
              >
                Please Select One
              </MenuItem>
            </TextField>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="seat-number"
                fullWidth
                label="Seat Number"
                type="string"
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="occupied"
                fullWidth
                label="Occupied ?"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem
                  selected
                  key="Please Select One"
                  value="Please Select One"
                >
                  Please Select One
                </MenuItem>
              </TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="shift-timings"
                fullWidth
                label="Shift Timings"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem
                  selected
                  key="Please Select One"
                  value="Please Select One"
                >
                  Please Select One
                </MenuItem>
              </TextField>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
export default OtherDetails;
