import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";

function VendorDetails() {
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="vendor-name"
              fullWidth
              label="Vendor Name"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
                value= "Please Select"
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="vendor-employee-id"
              fullWidth
              label="Vendor Employee Id"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="vendor-employee-email"
              fullWidth
              label="Vendor Emplyee Email"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="Vendor-Unit"
              fullWidth
              label="Vendor Unit"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value= "Please Select"
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="vendor-manager-email"
                fullWidth
                label="Vendor manager Email"
                type="string"
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="vendor-account-manager-email"
                fullWidth
                label="Vendor account manager email"
                type="string"
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
export default VendorDetails;
