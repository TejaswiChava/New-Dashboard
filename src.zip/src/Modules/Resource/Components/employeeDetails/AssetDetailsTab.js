import React from "react";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Button from "@material-ui/core/Button";
import Radio from "@material-ui/core/Radio";
import Table from '../../../../SharedModules/Table/Components/Table';

const headCells = [
    { id: "sNo", numeric: false, disablePadding: true, label: "S No" },
    { id: "softwareName", numeric: true, disablePadding: false, label: "Software Name" },
    { id: "accessStartDate", numeric: true, disablePadding: false, label: "Access Start Date" },
    { id: "accessEndDate", numeric: true, disablePadding: false, label: "Access End Date" },
  ];
  function createData(sNo, softwareName, accessStartDate, accessEndDate) {
    return { sNo, softwareName, accessStartDate, accessEndDate };
  }
  
  const rows = [
    createData("1", "VS code", '01/01/2020', '01/01/2020'),
    createData("2", "STS", '01/01/2020', '01/01/2020'),
    createData("3", "Maven", '01/01/2020', '01/01/2020'),
    createData("4", "Open JDK",'01/01/2020', '01/01/2020'),
  ];

function AssetDetails() {
  const [software, setSoftware] = React.useState(false);
  const [hardware, setHardware] = React.useState(true);
  const changeSoftware = () => {
    console.log("soft");
    setSoftware(true);
    setHardware(false);
  };
  const chnageHardware = () => {
    console.log("hard");
    setHardware(true);
    setSoftware(false);
  };
  return (
    <div>
      <div className="tab-heading float-left">
        {"Employee Asset Check list"}
      </div>
      <Button
        variant="contained"
        color="primary"
        style={{ float: "right" }}
        onClick={chnageHardware}
      >
        Hardware
      </Button>
      <Button
        variant="contained"
        color="primary"
        style={{ float: "right" }}
        onClick={changeSoftware}
      >
        Software
      </Button>
      {hardware ? (
        <div>
          <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="secured"
                control={<Checkbox color="primary" checked={true} />}
                label="Secured the Existing Employee's PGP Passphrase ?"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="lan"
                control={<Checkbox color="primary" checked={true} />}
                label="LAN and Facility access (with Cable)"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="voice"
                control={<Checkbox color="primary" checked={true} />}
                label="Employee Id/ Security Card"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="pager"
                control={<Checkbox color="primary" checked={true} />}
                label="Manual Documents"
                labelPlacement="start"
              />
            </div>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="secured"
                control={<Checkbox color="primary" checked={true} />}
                label="Company Credit card "
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="lan"
                control={<Checkbox color="primary" checked={true} />}
                label="Telephone Credit Card"
                labelPlacement="start"
              />
            </div>

            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="secured"
                control={<Checkbox color="primary" checked={true} />}
                label="Air Travel cards "
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="lan"
                control={<Checkbox color="primary" checked={true} />}
                label="Office/Desk keys"
                labelPlacement="start"
              />
            </div>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="voice"
                control={<Checkbox color="primary" checked={true} />}
                label="Voice Mail"
                labelPlacement="start"
              />
            </div>

            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="voice"
                control={<Checkbox color="primary" checked={true} />}
                label="Headset"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="pager"
                control={<Checkbox color="primary" checked={true} />}
                label="Pager"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form">
              <label className="MuiFormLabel-root small-label no-margin">
                Laptop/Computer
              </label>
              <div className="sub-radio">
                <Radio name="laptop" value="Yes" id="laptop" />
                <label
                  for="laptop"
                  className="text-black"
                  style={{
                    fontSize: "14px",
                    fontWeight: "650",
                    color: "#274463",
                  }}
                >
                  Laptop
                </label>
                <Radio
                  className="ml-2"
                  name="computer"
                  value="computer"
                  id="Computer"

                  //   onChange={props.handleChangeDetails('void')}
                  //   checked={props.correctionViewDetails.void === 'No'}
                />
                <label
                  for="computer"
                  className="text-black"
                  style={{
                    fontSize: "14px",
                    fontWeight: "650",
                    color: "#274463",
                  }}
                >
                  Computer
                </label>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div>
             <div className="form-wrapper">
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="software"
                control={<Checkbox color="primary" checked={true} />}
                label="Software(Licensed)"
                labelPlacement="start"
              />
            </div>
            <div className="mui-custom-form sub-radio float-left  margin-top-24">
              <FormControlLabel
                value="vdi"
                control={<Checkbox color="primary" checked={true} />}
                label="VDI Access"
                labelPlacement="start"
              />
            </div>
            </div>
            <Table tableData = {rows} headCells = {headCells} />
        </div>
      )}
    </div>
  );
}

export default AssetDetails;
