import React, { useState } from "react";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import AppBar from "@material-ui/core/AppBar";
import { makeStyles } from "@material-ui/core/styles";
import TabPanel from "../../../../SharedModules/TabPanel/TabPanel";
import EmployeeDetails from "./EmplyeeDetailsTab";
import ContractDetails from "./ContractDetailsTab";
import OtherDetails from "./OtherDetailsTab";
import VendorDetails from "./VendorDetailsTab";
import SkillSetDetails from "./SkillSetDetailsTab";
import CertificationDetails from "./CertificationDetailsTab";
import AssetDetails from "./AssetDetailsTab";
import "../employeeDetails.scss";

const useStyles = makeStyles({
  tab100: {
    minWidth: 0,
  },
});

function EmployeeAdd() {
  const classes = useStyles();

  // Tab Value
  const [value, setValue] = useState(0);

  // Tab Change Event
  const handleChangeTabs = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <div className="pos-relative w-100 h-100">
      <div className="tabs-container">
        <div className="tab-header">
          <div className="tab-heading float-left">{"Add Employee"}</div>
        </div>
        <div className="tab-body">
          <EmployeeDetails />
          <div className="tab-panelbody">
            <div className="tab-holder mb-3 mt-2">
              <AppBar position="static">
                <Tabs
                  variant="fullWidth"
                  value={value}
                  onChange={handleChangeTabs}
                  aria-label="simple tabs example"
                >
                  <Tab
                    label="Contract Details"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab
                    label="Other Details"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab
                    label="Vendor Details"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab label="Skill Set" classes={{ root: classes.tab100 }} />
                  <Tab
                    label="Certification"
                    classes={{ root: classes.tab100 }}
                  />
                  <Tab label="Assets" classes={{ root: classes.tab100 }} />
                </Tabs>
              </AppBar>
              <TabPanel value={value} index={0}>
                <div className="tab-holder my-3 p-0">
                  <ContractDetails />
                </div>
              </TabPanel>
              <TabPanel value={value} index={1}>
                <div className="tab-holder my-3 p-0">
                  <OtherDetails />
                </div>
              </TabPanel>
              <TabPanel value={value} index={2}>
                <div className="tab-holder my-3 p-0">
                  <VendorDetails />
                </div>
              </TabPanel>
              <TabPanel value={value} index={3}>
                <div className="tab-holder my-3 p-0">
                  <SkillSetDetails />
                </div>
              </TabPanel>
              <TabPanel value={value} index={4}>
                <div className="tab-holder my-3 p-0">
                  <CertificationDetails />
                </div>
              </TabPanel>
              <TabPanel value={value} index={5}>
                <div className="tab-holder my-3 p-0">
                  <AssetDetails />
                </div>
              </TabPanel>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EmployeeAdd;
