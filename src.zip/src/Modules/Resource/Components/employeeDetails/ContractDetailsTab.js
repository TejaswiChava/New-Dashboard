import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";

function ContarctDetails() {
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="typeof-contract"
              fullWidth
              label="Type Of Contract"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value="Please Select"
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Program"
              fullWidth
              label="Program"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="cluster-name"
              fullWidth
              label="Cluster Name"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
              value= "Please Select"
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="mui-custom-form with-select">
            <TextField
              id="sbu"
              fullWidth
              label="SBU"
              type="string"
              select
              inputProps={{ maxLength: 15 }}
                value= "Please Select"
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem
                selected
                key="Please Select"
                value="Please Select"
              >
                Please Select
              </MenuItem>
            </TextField>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="cost-center"
                fullWidth
                label="Cost Center"
                type="string"
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="Lob-Head"
                fullWidth
                label="Lob Head"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                value= "Please Select"
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem
                  selected
                  key="Please Select"
                  value="Please Select"
                >
                  Please Select
                </MenuItem>
              </TextField>
            </div>
            <div className="mui-custom-form with-select">
              <TextField
                id="Typeof-billing"
                fullWidth
                label="Type of billing"
                type="string"
                select
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem
                  selected
                  key="Please Select One"
                  value="Please Select One"
                >
                  Please Select One
                </MenuItem>
              </TextField>
            </div>
            <div className="mui-custom-form">
              <TextField
                id="Crid"
                fullWidth
                label="CR Id"
                type="string"
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
          </div>
          <div className="form-wrapper">
            <div className="mui-custom-form">
              <TextField
                id="Purchaser-order"
                fullWidth
                label="Purchase Order"
                type="string"
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
            <div className="mui-custom-form">
              <TextField
                id="Position-Id"
                fullWidth
                label="Position Id"
                type="string"
                inputProps={{ maxLength: 15 }}
                // value={}
                // onChange={}
                InputLabelProps={{
                  shrink: true,
                }}
              ></TextField>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
export default ContarctDetails;
