import React from "react";
import Table from "../../../../SharedModules/Table/Components/Table";

const headCells = [
  { id: "sno", numeric: false, disablePadding: true, label: "S no" },
  { id: "name", numeric: false, disablePadding: true, label: "Name" },
  { id: "date", numeric: true, disablePadding: false, label: "Date" },
  { id: "qualified", numeric: true, disablePadding: false, label: "Qualified" },
];
function createData(sno, name, date, qualified) {
  return { sno, name, date, qualified };
}

const rows = [
  createData("1", "HIPPA", "01/01/2020", "Qualified"),
  createData("2", "SAQ", "01/01/2020", "Qualified"),
  createData("3", "JAVA", "01/01/2020", "Qualified"),
  createData("4", "Angular", "01/01/2020", "Qualified"),
  createData("5", ".Net", "01/01/2020", "Qualified"),
];

function CertificationDetails() {
  return <Table tableData={rows} headCells={headCells} />;
}
export default CertificationDetails;
