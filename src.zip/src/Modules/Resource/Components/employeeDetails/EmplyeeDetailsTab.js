import React from "react";
import TextField from "@material-ui/core/TextField";

function EmployeeDetailsTab() {
  return (
    <div>
      <form autoComplete="off">
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="CID"
              fullWidth
              label="CID"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Contact-number"
              fullWidth
              label="Contact Number"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Conduent-email"
              fullWidth
              label="Conduent Email"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Conduent-manager-email"
              fullWidth
              label="Conduent Manager Email"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
        </div>
        <div className="form-wrapper">
          <div className="mui-custom-form">
            <TextField
              id="First-Name"
              fullWidth
              label="First Name"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Middle-name"
              fullWidth
              label="Middle Name"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Last-Name"
              fullWidth
              label="Last Name"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
          <div className="mui-custom-form">
            <TextField
              id="Conduent-vendor-manager-email"
              fullWidth
              label="Conduent Vendor Manager Email"
              type="string"
              inputProps={{ maxLength: 15 }}
              // value={}
              // onChange={}
              InputLabelProps={{
                shrink: true,
              }}
            ></TextField>
          </div>
        </div>
      </form>
    </div>
  );
}

export default EmployeeDetailsTab;
