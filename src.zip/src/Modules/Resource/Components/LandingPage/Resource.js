import React from 'react';
import Table from '../../../../SharedModules/Table/Components/Table';
import Charts from '../../../../SharedModules/Charts/Components/CustomPieChart'
import CustomDoughnutChart from '../../../../SharedModules/Charts/Components/CustomDoughnutChart'
import { PieChartTitle } from 'devextreme-react/pie-chart';
import Button from '@material-ui/core/Button';
import { useHistory } from "react-router-dom";



const headCells = [


  { id: 'name', numeric: false, disablePadding: true, label: 'CID' },
  { id: 'calories', numeric: true, disablePadding: false, label: 'Name' },
  { id: 'fat', numeric: true, disablePadding: false, label: 'Vendor Employee ID' },
  { id: 'carbs', numeric: true, disablePadding: false, label: 'Status' },
  { id: 'action', numeric: true, disablePadding: false, label: 'Action', isAction: true },
  
];
function createData(name , calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

const rows = [
  createData('C5023450', 'Rashmita', '790231', 'Active' ),
  createData('C5023451', 'Tejaswi', '790876', 'Active'),
  createData('C5023452', 'Manisha', '645632', 'Inactive'),
  createData('C5023453', 'VenkataKeerthi', '678954', 'Active'),
  
];
const pieChartTitle="Employee Count";
 const areas1 = [{
  country: 'FSS',
  area: 12
}, {
  country: 'Eligiblity',
  area: 7
}, {
  country: 'RXD',
  area: 7
}, {
  country: 'SLR',
  area: 7
}, {
  country: 'EDI',
  area: 6
}, {
  country: 'CWP',
  area: 5
}, {
  country: 'GHS Infra',
  area: 2
}, {
  country: 'Maven',
  area: 55
}];
 const internetLanguages1 = [{
  language: 'Active',
  percent: 55.5
},   {
  language: 'Inactive',
  percent: 28
}];

const mystyle = {
  color: "white",
  backgroundColor: "#225675",
  padding: "10px",
  fontFamily: "Arial",
  float:"right"
};
function Resource() {
  const history = useHistory();
  const routeChange = () =>{ 
    let path = `/employee`; 
    history.push(path);
  }
    
    return (
      <div className="Resource-content container-fluid">
        <div className = 'Resouce-Charts' style={{display: 'flex'}}>

        <div style={{width:'50%'}}>  <Charts dataSource={areas1} pieChartTitle={pieChartTitle} /></div>

        <div style={{width:'50%'}} >  <CustomDoughnutChart dataSource={internetLanguages1}/></div>
        </div>
        <Button  variant="contained"    style = { mystyle} onClick={routeChange}>
        Add Employee
      </Button>
        <Table tableData={rows} headCells={headCells}></Table>
      </div>
    );

    
  }
  
  export default Resource;