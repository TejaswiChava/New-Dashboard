import React from "react";
import '../Home.scss';
import { CardDeck, Card, Button, Overlay, Accordion } from 'react-bootstrap';
import CustomCarousel from '../../../SharedModules/Layout/Components/CustomCarousel';
// import Projects from '../../Dashboard/Components/Projects';
import PersonIcon from '@material-ui/icons/Person';
import EmojiEventsIcon from '@material-ui/icons/EmojiEvents';
import LocalLibraryOutlinedIcon from '@material-ui/icons/LocalLibraryOutlined';
import DvrIcon from '@material-ui/icons/Dvr';
import AssignmentIcon from '@material-ui/icons/Assignment';
import AttachMoneyIcon from '@material-ui/icons/AttachMoney';
import ArrowRightAltIcon from '@material-ui/icons/ArrowRightAlt';
import DoubleArrowIcon from '@material-ui/icons/DoubleArrow';
import { useHistory } from "react-router-dom";

export default function Home() {
    const history = useHistory();
    const routeChange = () =>{ 
      let path = `/resource`; 
      history.push(path);
    }
    return (
    <>
    {/* <CustomCarousel/> */}
        <section id='hero' className='d-flex' 
        // style={{background: 'url(./hero3.jpg) top right', backgroundSize: 'cover' }} 
        >
            
            <div className='container px-sm-0'>
                <h1 className='display-4 text-right'>One stop shop </h1>
                <h1 className='display-4 text-right'>for all your project needs</h1>
                <h5 className='text-right'>Track progress, manage resources, identify 
                    risks and forecast future needs</h5>
                   <h5 className='text-right'> Empowering you to plan better 
                    and improve decision making</h5>
            </div>
        </section>        
        <main id='main'>            
            <section id='about-us'>
                <div className='container px-sm-0'>
                    <div className='row my-3'>
                        <div className='col-sm-4 d-flex align-items-stretch'>
                            <div className='content'>
                                <h4 className='pb-2'>Project Management</h4>
                                <p>Track project status and draft plans for risk mitigation.</p>
                                <p>View upcoming projects in pipeline and help plan demands and resource allocation.</p>
                            </div>
                        </div>
                        <div className='col-sm-8 d-flex align-items-stretch'>
                            <div className='icon-boxes d-flex flex-column justify-content-center'>
                                <div className='row'>
                                    <div className='col-lg-4 d-flex align-items-stretch'>
                                        <div className='icon-box mt-4 mt-xl-0'>
                                            <h4>Knowledge Management</h4>
                                            <p>Access different 
                                                technical and domain related documents at account level and project level.</p>
                                        </div>
                                    </div>
                                    <div className='col-lg-4 d-flex align-items-stretch' onClick={routeChange}>
                                        <div className='icon-box mt-4 mt-xl-0'>
                                            <h4>Talent Management</h4>
                                            <p>Manage talents and plan upskilling needs across the organization. </p>
                                        </div>
                                    </div>
                                    <div className='col-lg-4 d-flex align-items-stretch'>
                                        <div className='icon-box mt-4 mt-xl-0'>
                                            <h4>Report Creation</h4>
                                            <p>Automate generation of status reports on the click of a mouse.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        
            <section id='counts'>
                <div className='container-fluid'>
                    <div className='row'>
                        <div className='col-lg-3 col-md-6'>
                            <div className='card count-box'>
                                <AssignmentIcon className='icon' />
                                <h1 className='p-2'>20</h1>
                                <h6>Projects</h6>
                            </div>
                        </div>
                        <div className='col-lg-3 col-md-6 mt-5 mt-md-0'>
                            <div className='card count-box'>
                                <PersonIcon className='icon' />
                                <h1 className='p-2'>100</h1>
                                <h6>Employees</h6>
                            </div>
                        </div>
                        <div className='col-lg-3 col-md-6 mt-5 mt-lg-0'>
                            <div className='card count-box'>
                                <LocalLibraryOutlinedIcon className='icon' />
                                <h1 className='p-2'>50+</h1>
                                <h6>Agile Certified Professionals</h6>
                            </div>
                        </div>
                        <div className='col-lg-3 col-md-6 mt-5 mt-lg-0'>
                            <div className='card count-box'>
                                <AttachMoneyIcon className='icon' />
                                <h1 className='p-2'>$30</h1>
                                <h6>Billion Total Revenue</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id='awards'>
                <div className='awards-header text-center'>
                    <EmojiEventsIcon/>
                    <h1>Achievements</h1>
                </div>
                <div className='container'>
                    <div className='card'>
                        <div className='card-img-box'>
                            <img className="card-img-top" src="./kirti.png" alt="woman 1"/>
                        </div>
                        <div className="card-body">
                            <h2>Kirti Saraogi</h2>
                            <p className="card-text">Kirti has been awarded as Performer of the year.</p>
                        </div>
                    </div>
                    <div className='card'>
                        <div className='card-img-box'>
                            <img className="card-img-top" src="./nitin.png" alt="man 1"/>
                        </div>
                        <div className="card-body">
                            <h2>Nitin Kamath</h2>
                            <p className="card-text">People's manager of the year award goes to Nitin Kamath.</p>
                        </div>
                    </div>
                    <div className='card'>
                        <div className='card-img-box'>
                            <img className="" src="./sandeep.png" alt="man 1"/>
                        </div>
                        <div className="card-body">
                            <h2>Sandeep Biswal</h2>
                            <p className="card-text">He has been awarded the best manager award in conduent.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section id='news'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-xl-7 col-lg-7 col-12'>
                            <section className='event-section'>
                                <div className='row'>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event1.jpg'/>
                                    </div>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event2.jpg'/>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='event-header'>
                                        <h1>Events</h1>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event2.jpg'/>
                                    </div>
                                    <div className='col-lg py-1'>
                                        <img className='d-block w-100' src='./event1.jpg'/>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div className='col-xl-5 col-lg-5 col-12'>
                            <section className='news-section'>
                                <h1>In the news</h1>
                                <div className='news-row'>
                                    <a href='#'>Lorem ipsum dolor sit amet, consectetur adipiscing elit</a>
                                </div>
                                <div className='news-row'>
                                    <a href='#'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do </a>
                                </div>
                                <div className='news-row'>
                                    <a href='#'>Lorem ipsum dolor sit amet, consectetur adipiscing</a>
                                </div>
                                <div className='news-row'>
                                    <a href='#'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut</a>
                                </div>
                                <div className='news-row'>
                                    <a href='#'>See All<DoubleArrowIcon/></a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </>
    )
}