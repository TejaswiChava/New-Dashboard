import React from 'react';
import { BrowserRouter as Router } from "react-router-dom";
import Layout from '../src/SharedModules/Layout/Components/Layout';


function App() {
  return (
    <Router>
      <Layout/>
    </Router>
  );
}

export default App;
